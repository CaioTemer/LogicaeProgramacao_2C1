﻿namespace AppLista03_Logica
{
    partial class FrmExercicio01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSominha = new System.Windows.Forms.Button();
            this.btnMedinha = new System.Windows.Forms.Button();
            this.btnPorcentagem = new System.Windows.Forms.Button();
            this.lblex = new System.Windows.Forms.Label();
            this.lblnumero1 = new System.Windows.Forms.Label();
            this.txtnumero1 = new System.Windows.Forms.TextBox();
            this.txtnumero2 = new System.Windows.Forms.TextBox();
            this.txtnumero3 = new System.Windows.Forms.TextBox();
            this.lblnumero2 = new System.Windows.Forms.Label();
            this.lblnumero3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSominha
            // 
            this.btnSominha.Location = new System.Drawing.Point(452, 70);
            this.btnSominha.Name = "btnSominha";
            this.btnSominha.Size = new System.Drawing.Size(98, 23);
            this.btnSominha.TabIndex = 0;
            this.btnSominha.Text = "a)Soma";
            this.btnSominha.UseVisualStyleBackColor = true;
            this.btnSominha.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnMedinha
            // 
            this.btnMedinha.Location = new System.Drawing.Point(452, 192);
            this.btnMedinha.Name = "btnMedinha";
            this.btnMedinha.Size = new System.Drawing.Size(98, 23);
            this.btnMedinha.TabIndex = 1;
            this.btnMedinha.Text = "b)Média";
            this.btnMedinha.UseVisualStyleBackColor = true;
            this.btnMedinha.Click += new System.EventHandler(this.btnMedinha_Click);
            // 
            // btnPorcentagem
            // 
            this.btnPorcentagem.Location = new System.Drawing.Point(452, 312);
            this.btnPorcentagem.Name = "btnPorcentagem";
            this.btnPorcentagem.Size = new System.Drawing.Size(98, 23);
            this.btnPorcentagem.TabIndex = 2;
            this.btnPorcentagem.Text = "c)Porcentagem";
            this.btnPorcentagem.UseVisualStyleBackColor = true;
            this.btnPorcentagem.Click += new System.EventHandler(this.btnPorcentagem_Click);
            // 
            // lblex
            // 
            this.lblex.AutoSize = true;
            this.lblex.Location = new System.Drawing.Point(293, 22);
            this.lblex.Name = "lblex";
            this.lblex.Size = new System.Drawing.Size(65, 13);
            this.lblex.TabIndex = 3;
            this.lblex.Text = "Exercicio 01";
            // 
            // lblnumero1
            // 
            this.lblnumero1.AutoSize = true;
            this.lblnumero1.Location = new System.Drawing.Point(183, 58);
            this.lblnumero1.Name = "lblnumero1";
            this.lblnumero1.Size = new System.Drawing.Size(38, 13);
            this.lblnumero1.TabIndex = 4;
            this.lblnumero1.Text = "NUM1";
            // 
            // txtnumero1
            // 
            this.txtnumero1.Location = new System.Drawing.Point(156, 85);
            this.txtnumero1.Name = "txtnumero1";
            this.txtnumero1.Size = new System.Drawing.Size(100, 20);
            this.txtnumero1.TabIndex = 5;
            this.txtnumero1.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtnumero2
            // 
            this.txtnumero2.Location = new System.Drawing.Point(156, 183);
            this.txtnumero2.Name = "txtnumero2";
            this.txtnumero2.Size = new System.Drawing.Size(100, 20);
            this.txtnumero2.TabIndex = 6;
            // 
            // txtnumero3
            // 
            this.txtnumero3.Location = new System.Drawing.Point(156, 315);
            this.txtnumero3.Name = "txtnumero3";
            this.txtnumero3.Size = new System.Drawing.Size(100, 20);
            this.txtnumero3.TabIndex = 7;
            // 
            // lblnumero2
            // 
            this.lblnumero2.AutoSize = true;
            this.lblnumero2.Location = new System.Drawing.Point(183, 139);
            this.lblnumero2.Name = "lblnumero2";
            this.lblnumero2.Size = new System.Drawing.Size(38, 13);
            this.lblnumero2.TabIndex = 8;
            this.lblnumero2.Text = "NUM2";
            // 
            // lblnumero3
            // 
            this.lblnumero3.AutoSize = true;
            this.lblnumero3.Location = new System.Drawing.Point(183, 281);
            this.lblnumero3.Name = "lblnumero3";
            this.lblnumero3.Size = new System.Drawing.Size(38, 13);
            this.lblnumero3.TabIndex = 9;
            this.lblnumero3.Text = "NUM3";
            // 
            // FrmExercicio01
            // 
            this.ClientSize = new System.Drawing.Size(691, 455);
            this.Controls.Add(this.lblnumero3);
            this.Controls.Add(this.lblnumero2);
            this.Controls.Add(this.txtnumero3);
            this.Controls.Add(this.txtnumero2);
            this.Controls.Add(this.txtnumero1);
            this.Controls.Add(this.lblnumero1);
            this.Controls.Add(this.lblex);
            this.Controls.Add(this.btnPorcentagem);
            this.Controls.Add(this.btnMedinha);
            this.Controls.Add(this.btnSominha);
            this.Name = "FrmExercicio01";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnum1;
        private System.Windows.Forms.Label lblnum2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label lblnum3;
        private System.Windows.Forms.Label lblexercicio;
        private System.Windows.Forms.Button btnmedia;
        private System.Windows.Forms.Button btnsoma;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnSominha;
        private System.Windows.Forms.Button btnMedinha;
        private System.Windows.Forms.Button btnPorcentagem;
        private System.Windows.Forms.Label lblex;
        private System.Windows.Forms.Label lblnumero1;
        private System.Windows.Forms.TextBox txtnumero1;
        private System.Windows.Forms.TextBox txtnumero2;
        private System.Windows.Forms.TextBox txtnumero3;
        private System.Windows.Forms.Label lblnumero2;
        private System.Windows.Forms.Label lblnumero3;
    }
}

