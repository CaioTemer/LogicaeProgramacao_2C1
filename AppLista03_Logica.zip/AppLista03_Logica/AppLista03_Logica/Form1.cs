﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtnumero1.Text);
            float num3 = float.Parse(txtnumero3.Text);
            float soma;
            
            soma = num1 + num3;
            MessageBox.Show("Soma = " + soma);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnMedinha_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtnumero1.Text);
            float num2 = float.Parse(txtnumero2.Text);
            float num3 = float.Parse(txtnumero3.Text);
            float media;

            media = (num1 + num2 + num3)/3;

            MessageBox.Show("Média = " + media);
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtnumero1.Text);
            float num2 = float.Parse(txtnumero2.Text);
            float num3 = float.Parse(txtnumero3.Text);
            float porcentagem;

            porcentagem = num1/(num1 + num2 + num3) * 100;

            MessageBox.Show("Porcentagem = " + porcentagem);
        }
    }
}
